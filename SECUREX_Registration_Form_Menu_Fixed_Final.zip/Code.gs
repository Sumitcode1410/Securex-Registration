const CONFIG = {
  SOCIETY_NAME: "SecureX Cyber Club",
  SOCIETY_SUBTITLE: "Computer Science & Engineering Department",
  EVENT_NAME: "CYBER QUEST 2026",
  EVENT_TAG: "SECUREX • 2026",
  EVENT_DESCRIPTION: "Think. Explore. Learn. Aware. Join SecureX Cyber Club for CYBER QUEST 2026 — featuring cyber challenges, real-world scenario awareness, exciting prizes, and opportunities to learn, compete and grow together.",
  DATE: "2 September 2026",
  DAY: "Wednesday",
  TIME: "2 PM Onwards",
  VENUE: "B-120 Seminar Hall",
  MENTOR: "Mr. Vikas Bhatnagar (Faculty Convener)",
  COLLEGE: "Moradabad Institute of Technology (MIT)",
  WHAT_YOU_LEARN: [
    "Cyber Challenges",
    "Real-world scenario awareness",
    "Exciting Prizes",
    "Learn. Compete. Grow Together."
  ],
  REGISTRATION_FEE: "FREE"
};

const SHEET_NAME = "Registrations";

function doGet() {
  return HtmlService.createTemplateFromFile("index")
    .evaluate()
    .setTitle(CONFIG.SOCIETY_NAME + " | Event Registration")
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function getConfig() {
  return CONFIG;
}

function setupSheet() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(SHEET_NAME);
  if (!sheet) sheet = ss.insertSheet(SHEET_NAME);

  const headers = [
    "Timestamp", "Registration ID", "Full Name", "Roll Number",
    "Email", "Mobile", "Academic Year", "Branch", "Section",
    "Event", "Status"
  ];

  if (sheet.getLastRow() === 0) {
    sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
    sheet.setFrozenRows(1);
    sheet.getRange(1, 1, 1, headers.length).setFontWeight("bold");
  }
  return "Sheet ready";
}

function saveRegistration(data) {
  validate_(data);
  setupSheet();

  const lock = LockService.getScriptLock();
  lock.waitLock(10000);

  try {
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const sheet = ss.getSheetByName(SHEET_NAME);

    const id = makeRegistrationId_();
    const row = [
      new Date(),
      id,
      clean_(data.name),
      clean_(data.roll),
      clean_(data.email),
      clean_(data.mobile),
      clean_(data.year),
      clean_(data.branch),
      clean_(data.section),
      CONFIG.EVENT_NAME,
      "REGISTERED"
    ];

    sheet.appendRow(row);

    return {
      success: true,
      registrationId: id,
      name: clean_(data.name),
      roll: clean_(data.roll),
      email: clean_(data.email),
      mobile: clean_(data.mobile),
      year: clean_(data.year),
      branch: clean_(data.branch),
      section: clean_(data.section),
      event: CONFIG.EVENT_NAME,
      date: CONFIG.DATE,
      time: CONFIG.TIME,
      venue: CONFIG.VENUE
    };
  } finally {
    lock.releaseLock();
  }
}

function findRegistration(query) {
  const q = String(query || "").trim().toLowerCase();
  if (!q) return { success: false, message: "Enter Roll Number, Email or Registration ID." };

  setupSheet();
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME);
  const values = sheet.getDataRange().getValues();

  for (let i = 1; i < values.length; i++) {
    const row = values[i];
    const id = String(row[1] || "").toLowerCase();
    const roll = String(row[3] || "").toLowerCase();
    const email = String(row[4] || "").toLowerCase();

    if (q === id || q === roll || q === email) {
      return {
        success: true,
        registrationId: row[1],
        name: row[2],
        roll: row[3],
        email: row[4],
        mobile: row[5],
        year: row[6],
        branch: row[7],
        section: row[8],
        event: row[9],
        status: row[10],
        date: CONFIG.DATE,
        time: CONFIG.TIME,
        venue: CONFIG.VENUE
      };
    }
  }

  return { success: false, message: "Registration not found." };
}

function markAttendance(registrationId) {
  const id = String(registrationId || "").trim().toLowerCase();
  if (!id) return { success: false, message: "Invalid registration ID." };

  setupSheet();
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME);
  const values = sheet.getDataRange().getValues();

  for (let i = 1; i < values.length; i++) {
    if (String(values[i][1]).toLowerCase() === id) {
      sheet.getRange(i + 1, 11).setValue("CHECKED-IN");
      return {
        success: true,
        registrationId: values[i][1],
        name: values[i][2],
        message: "Attendance marked successfully."
      };
    }
  }

  return { success: false, message: "Registration ID not found." };
}

function makeRegistrationId_() {
  const now = new Date();
  const stamp = Utilities.formatDate(now, Session.getScriptTimeZone(), "yyyyMMddHHmmss");
  const random = Math.floor(100 + Math.random() * 900);
  return "SX-" + stamp + "-" + random;
}

function validate_(d) {
  if (!d) throw new Error("No registration data received.");

  const required = ["name", "roll", "email", "mobile", "year", "branch", "section"];
  required.forEach(k => {
    if (!String(d[k] || "").trim()) throw new Error("Please fill all required fields.");
  });

  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(d.email).trim())) {
    throw new Error("Please enter a valid email address.");
  }

  const digits = String(d.mobile).replace(/\D/g, "");
  if (digits.length !== 10) {
    throw new Error("Mobile number must contain 10 digits.");
  }
}

function clean_(value) {
  return String(value || "").trim().replace(/[<>]/g, "");
}
